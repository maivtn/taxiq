
// Highlight active nav link based on current page
document.addEventListener('DOMContentLoaded', function() {
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.remove('active');
    if (a.getAttribute('href') === current) a.classList.add('active');
  });
});
