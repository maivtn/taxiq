NEXORA TOUCH — TÀI LIỆU HƯỚNG DẪN
=====================================
Bitcoin Nail Bar | Phiên: 28/06/2026

CẤU TRÚC:
  index.html         → Trang chủ tổng quan
  quick-pay.html     → Hướng dẫn Quick Pay (5 bước + 7 mẹo)
  pay-engine.html    → Cấu hình lương (ăn chia, kỳ TT, bonus)
  weekly-payroll.html→ Bảng lương tuần + cách thanh toán
  payout-hub.html    → Thanh toán 1099 qua Payout Hub
  tax-1099.html      → Tax Center, thống kê & in 1099-NEC
  changelog.html     → Toàn bộ nội dung đã bổ sung/cập nhật
  assets/style.css   → Stylesheet chung
  assets/nav.js      → Navigation script

CÁCH SỬ DỤNG:
  Mở file index.html bằng trình duyệt (Chrome/Edge/Firefox)
  Không cần server — hoạt động offline hoàn toàn.

NỘI DUNG ĐÃ BỔ SUNG:
  [BUG] Quick Pay: ô nhập tiền bị ẩn — đã giải thích
  [NEW] Quick Pay: hướng dẫn 5 bước đầy đủ
  [OPT] Quick Pay: 7 mẹo tối ưu
  [NEW] Pay Engine: 4 kiểu lương + bonus
  [FIX] Pay Engine: bổ sung Ăn Chia (bị thiếu)
  [FIX] Pay Engine: bổ sung Kỳ Thanh Toán (bị thiếu)
  [NEW] Bảng Lương Tuần: trả từng người / tất cả
  [NEW] Tax Center: thống kê 1099, checklist IRS
  [NEW] Payout Hub: quy trình 3 bước thanh toán 1099
